import asyncio
import struct
import time
import csv  
from bleak import BleakClient, BleakScanner
import matplotlib.pyplot as plt

DEVICE_ADDRESS = "96:18:FC:FA:30:FA"
SENSOR_SERVICE_UUID = "12345678-1234-5678-1234-56789abcdef0"
SENSOR_CHARACTERISTIC_UUID = "12345678-1234-5678-1234-56789abcdef1"

# Global variables to store time and sensor values
sensor_values = []
times = []
start_time = None  # Will be initialized when the first reading occurs
recording_duration = 10  # Record data for 10 seconds after the first sensor reading
recording_started = False  # Track whether recording has started


def notification_handler(sender, data):
    """
    Callback function to handle notifications from the BLE device.
    """
    global sensor_values, times, start_time, recording_started
    # Unpack the received bytes into a float (assuming little-endian format)
    scaled_sensor_value, = struct.unpack('<f', data)

    # Initialize the start time at the first sensor reading
    if not recording_started:
        start_time = time.time()
        recording_started = True
        print("Recording started...")

    # Get the current time relative to when the recording started
    current_time = time.time() - start_time

    # Only record data for the duration of 10 seconds after the first reading
    if current_time <= recording_duration:
        # Append sensor values and current time
        sensor_values.append(scaled_sensor_value)
        times.append(current_time)

        # Print the value for debugging purposes
        print(f"Time: {current_time:.2f}s, Sensor Value: {scaled_sensor_value}")
    else:
        # Stop recording after 10 seconds
        raise KeyboardInterrupt  # This will stop the BLE loop


async def main():
    print("Scanning for devices...")
    devices = await BleakScanner.discover()
    target_device = None
    for d in devices:
        if d.address.upper() == DEVICE_ADDRESS.upper():
            target_device = d
            break
    if target_device is None:
        print("Device not found. Make sure the device is on and in range.")
        return
    else:
        print(f"Found device: {target_device.name}, Address: {target_device.address}")
    
    async with BleakClient(target_device.address) as client:
        # Check if the client is connected
        if client.is_connected:
            print("Connected to device")
            
            # Start notification
            await client.start_notify(SENSOR_CHARACTERISTIC_UUID, notification_handler)
            print("Waiting for first sensor reading...")

            try:
                # Wait until a KeyboardInterrupt stops the loop after 10 seconds of data collection
                while True:
                    await asyncio.sleep(1)  # Continue listening for notifications
            except KeyboardInterrupt:
                print("Stopping notifications after 10 seconds.")
                await client.stop_notify(SENSOR_CHARACTERISTIC_UUID)


def save_data_to_csv(file_path):
    """Save the time and sensor values to a CSV file at the specified path."""
    with open(file_path, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Time (s)", "Sensor Value"])  
        writer.writerows(zip(times, sensor_values))  


if __name__ == "__main__":
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:  # No event loop is running
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    # Schedule the BLE main function in the event loop
    asyncio.ensure_future(main())

    # After the recording is done, save to CSV and plot the data
    async def finish_recording():
        try:
            # Wait for some time to allow the recording to finish (buffer time)
            await asyncio.sleep(recording_duration + 7.4)
        except KeyboardInterrupt:
            pass
        finally:
            if len(times) > 0:
                # Define the file path for saving the CSV file
                csv_file_path = r"C:\Users\catha\OneDrive - University College Dublin\Desktop\Research Assistant\BLUETOOTH\sensor_data.csv"
                
                # Save the data to the specified CSV file
                save_data_to_csv(csv_file_path)
                print(f"Data saved to {csv_file_path}")

                # Plot the sensor data
                plt.plot(times, sensor_values, lw=2)
                plt.xlabel('Time (s)')
                plt.ylabel('Sensor Value')
                plt.title('Sensor Data over 10 Seconds')
                plt.grid(True)
                plt.show()

            else:
                print("No data to save or plot.")

    # Schedule the finish_recording task to save and plot after the recording finishes
    asyncio.ensure_future(finish_recording())
